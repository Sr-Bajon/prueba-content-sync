document.addEventListener('deviceready', onDeviceReady, false);

var contentSyncSrc = 'https://github.com/Ismael-Rodriguez/prueba-content-sync/blob/master/sync.zip?raw=true';
var contentSyncId = 'mfapp';
var versionInitial = "1";
var manifest = {
  'files': [
        'img/logo.png',
        'index.html',
        'js/index.js'
   ]
};
var versionHttp = {
  url: 'https://raw.githubusercontent.com/Ismael-Rodriguez/prueba-content-sync/master/version.json',
  method: 'GET'
};

var api = {
  onDeviceReady: onDeviceReady,
  getNewVersion: getNewVersion,
  checkVersion: checkVersion,
  goToActualVersion: goToActualVersion,
  isThereCachedVersion: isThereCachedVersion,
  minorUpdate: minorUpdate,
  update: update,
  majorUpdate: majorUpdate
};

function onDeviceReady() {
  setTimeout(function(){
    debugger;
    if (window.localStorage) {
      var versionActual = localStorage.getItem('versionActual');

      if (versionActual === null){
        localStorage.setItem('versionActual', versionInitial);
        versionActual = versionInitial;
      }

      getNewVersion(versionActual, checkVersion);
    }
  }, 1000*15);
}

function getNewVersion(versionActual, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open(versionHttp.method, versionHttp.url);
  xhr.onload = function() {
    if (xhr.status === 200) {
      callback(null, versionActual, JSON.parse(xhr.responseText).version);
    } else {
      callback(xhr.status);
    }
  };
  xhr.send();
}

function checkVersion(err, versionActual, newVersion) {
  if(err) return false;

  if(newVersion === versionActual) goToActualVersion();

  if(newVersion === (versionActual + 1)) minorUpdate(newVersion);
  else majorUpdate(newVersion);
}

function goToActualVersion(){
  isThereCachedVersion(function(err, url){
    if(err) return false;

    window.location.href = url;
  });
}

function isThereCachedVersion(callback){
  var sync = ContentSync.sync({
    id: contentSyncId,
    type: 'local'
  });

  sync.on('complete', function(data) {
    if (data.localPath) {
      var url = "file://" + data.localPath + "/index.html";
      callback(null, url);
    }else {
      callback(new Error('No hay version cacheada'));
    }
  });

  sync.on('error', function(e) {
    callback(e);
  });
}

function minorUpdate(newVersion){
  isThereCachedVersion(function(err, url){
    var updateConf = {
      src: contentSyncSrc,
      id: contentSyncId,
      type: 'merge',
      copyCordovaAssets: false,
      copyRootApp: true,
      headers: false,
      trustHost: true
    };

    if(err){
      update(newVersion, updateConf);
    }else{
      updateConf.copyRootApp = false;
      update(newVersion, updateConf);
    }

  });

}

function update(newVersion, updateConf) {
  var sync = ContentSync.sync(updateConf);

  sync.on('complete', function(data) {
    if (data.localPath) {
      var url = "file://" + data.localPath + "/index.html";

      console.log('Sync complete ' + data + ' changing document.location ' + url);

      localStorage.setItem('versionActual', newVersion);

      ContentSync.loadUrl(url);
      window.location.href = url;
    }
  });

  sync.on('error', function(e) {
    console.log('no synced app. Loading main app');
  });
}

function majorUpdate(newVersion){
    var updateConf = {
      src: contentSyncSrc,
      id: contentSyncId,
      type: 'replace',
      copyCordovaAssets: true,
      copyRootApp: false,
      headers: false,
      trustHost: true
    };

    update(newVersion, updateConf);
}





/*****************************************************************************/
// function onDeviceReady() {
//   var path = localStorage.getItem('syncPath');
//   if (path) {
//     ContentSync.loadUrl(path);
//     // window.location.href = path;
//   }
//
//
//   var xhr = new XMLHttpRequest();
//   xhr.open('GET', 'https://raw.githubusercontent.com/Ismael-Rodriguez/prueba-content-sync/master/version.json');
//   xhr.onload = function() {
//     if (xhr.status === 200) {
//       var newVersion = JSON.parse(xhr.responseText).version;
//       checkVersion(newVersion);
//     } else {
//       console.log('Error al obtener el archivo de version.')
//       console.log(xhr.status)
//     }
//   };
//   xhr.send();
// }
//
// function checkVersion(newVersion) {
//   if (window.localStorage) {
//     var syncVersion = localStorage.getItem('syncVersion');
//
//     if (syncVersion === null) {
//       // se trata de la primera vez que se inicia la app, se hace una copia de
//       // todo a la nueva ubicación y se apunta ahí, de forma que cuando haya una
//       // actualiación se haga mediante merge con los archivos iniciales
//       firstTimeCopy(newVersion);
//     }
//
//     if (syncVersion !== null && syncVersion !== newVersion) {
//       // la versión es diferente y por lo tanto se va a descargar la actualización
//       updateApp(newVersion);
//     }
//
//   }
// }
//
// function firstTimeCopy(newVersion) {
//   var sync = ContentSync.sync({
//     src: null,
//     id: contentSyncId,
//     type: 'local',
//     copyRootApp: true
//   });
//
//   sync.on('complete', function(data) {
//     localStorage.setItem('syncVersion', newVersion);
//     var url = "file://" + data.localPath + "/index.html";
//     localStorage.setItem('syncPath', url);
//     window.location.reload();
//   });
// }
//
// function updateApp(newVersion) {
//   var sync = ContentSync.sync({
//     src: contentSyncSrc,
//     id: contentSyncId,
//     type: contentSyncType,
//     copyCordovaAssets: false,
//     copyRootApp: false,
//     headers: false,
//     trustHost: true
//   });
//
//   sync.on('complete', function(data) {
//     if (data.localPath) {
//       var url = "file://" + data.localPath + "/index.html";
//       localStorage.setItem('syncPath', url);
//
//       console.log('Sync complete ' + data + ' changing document.location ' + url);
//
//       localStorage.setItem('syncVersion', newVersion);
//
//       ContentSync.loadUrl(url);
//       // window.location.reload();
//       window.location.href = url;
//
//     }
//   });
//
//   sync.on('error', function(e) {
//     console.log('no synced app. Loading main app');
//   });
//
// }
